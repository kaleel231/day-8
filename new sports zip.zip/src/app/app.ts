import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Football } from './football/football';
import { Basketball } from './basketball/basketball';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Football, Basketball],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('sports');
}
