import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CalPractice } from './cal-practice/cal-practice';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CalPractice],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('calculator');
}
