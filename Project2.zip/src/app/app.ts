import { Component, signal } from '@angular/core';
import { Chatbox } from "./chatbox/chatbox";

@Component({
  selector: 'app-root',
  imports: [ Chatbox],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('project');
}
