import { Component } from '@angular/core';

@Component({
  selector: 'app-basketball',
  imports: [],
  templateUrl: './basketball.html',
  styleUrl: './basketball.css',
})
export class Basketball {

}
