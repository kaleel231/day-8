import { Component } from '@angular/core';

@Component({
  selector: 'app-cal-practice',
  templateUrl: './cal-practice.html',
  styleUrls: ['./cal-practice.css']
})
export class CalPractice {

  display: string = '';

  press(val: string) {
    this.display = this.display + val;
  }

  clear() {
    this.display = '';
  }

  calculate() {
    try {
      this.display = eval(this.display);
    } catch {
      this.display = 'Error';
    }
  }

}