import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-chatbox',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chatbox.html',
  styleUrls: ['./chatbox.css']
})
export class Chatbox {

  message: string = '';
  currentUser: string = 'Kaleel';

  users: string[] = ['Kaleel', 'Satham', 'vakkas'];

  messages: { user: string, text: string }[] = [];

  sendMessage(): void {
    if (this.message.trim() !== '') {
      this.messages.push({
        user: this.currentUser,
        text: this.message
      });
      this.message = '';
    }
  }

}